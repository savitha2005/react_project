import React, { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import './SeatSelection.css';

const SeatSelection = () => {
  const { movieId } = useParams();
  const [selectedSeats, setSelectedSeats] = useState([]);
  const navigate = useNavigate();

  const seats = Array.from({ length: 50 }, (_, i) => i + 1); 

  const toggleSeat = (seat) => {
    setSelectedSeats((prev) =>
      prev.includes(seat) ? prev.filter((s) => s !== seat) : [...prev, seat]
    );
  };

  const confirmSeats = () => {
    if (selectedSeats.length) {
      const bookings = JSON.parse(localStorage.getItem('bookings')) || [];
      const newBooking = {
        movieId,
        seats: selectedSeats,
        date: new Date().toLocaleDateString(),
      };
      localStorage.setItem('bookings', JSON.stringify([...bookings, newBooking]));

      navigate('/payment'); 
    } else {
      alert('Please select at least one seat');
    }
  };

  return (
    <div className="seat-selection">
      <h2>Select Your Seats</h2>
      <div className="seats">
        {seats.map((seat) => (
          <button
            key={seat}
            className={`seat ${selectedSeats.includes(seat) ? 'selected' : ''}`}
            onClick={() => toggleSeat(seat)}
          >
            {seat}
          </button>
        ))}
      </div>
      <button onClick={confirmSeats}>Confirm Seats</button>
    </div>
  );
};

export default SeatSelection;
