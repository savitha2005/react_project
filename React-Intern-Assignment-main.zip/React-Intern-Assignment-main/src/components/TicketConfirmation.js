// import React from 'react';
// import { useLocation } from 'react-router-dom';
// import './TicketConfirmation.css';
// const TicketConfirmation = () => {
//   const location = useLocation();
//   const { selectedSeats, movieId } = location.state || {};

//   const downloadTicket = () => {
//     alert('Ticket downloaded!');
//   };

//   return (
//     <div className="ticket-confirmation">
//       <h2>Ticket Confirmation</h2>
//       <p>Movie ID: {movieId}</p>
//       <p>Selected Seats: {selectedSeats.join(', ')}</p>
//       <button onClick={downloadTicket}>Download Ticket</button>
//     </div>
//   );
// };

// export default TicketConfirmation;
import React from 'react';
import { useLocation } from 'react-router-dom';
import axios from 'axios';
import './TicketConfirmation.css';

const TicketConfirmation = () => {
  const location = useLocation();
  const { selectedSeats, movieId } = location.state || {};

  const downloadTicket = async (e) => {
    e.preventDefault();
    console.log("Download Ticket button clicked"); // Log to see if this is triggered
    try {
      // POST request to book the ticket
      const response = await axios.post('https://api.tvmaze.com/search/shows?q=all', {
        movieId,
        seats: selectedSeats,
      });
  
      console.log("Response:", response); // Log the response
      // Handle success (you can customize this with your response data)
      if (response.status === 200) {
        alert('Ticket booked successfully and downloaded!');
        // Additional logic for downloading ticket can be placed here
      } else {
        alert('Failed to book the ticket.');
      }
    } catch (error) {
      console.error('Error booking the ticket:', error);
      alert('An error occurred while booking the ticket.');
    }
  };
  
  return (
    <div className="ticket-confirmation">
      <h2>Ticket Confirmation</h2>
      <p>Movie ID: {movieId}</p>
      <p>Selected Seats: {selectedSeats.join(', ')}</p>
      <button onClick={downloadTicket()}>Download Ticket</button>
    </div>
  );
};

export default TicketConfirmation;
