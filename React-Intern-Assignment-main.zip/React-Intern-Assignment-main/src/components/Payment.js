import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Payment.css';

const Payment = () => {
  const [paymentMethod, setPaymentMethod] = useState('');
  const navigate = useNavigate();

  const handlePayment = (e) => {
    e.preventDefault();
    if (paymentMethod) {
      alert('Payment successful! Your ticket has been booked.');
      navigate('/account'); 
    } else {
      alert('Please select a payment method');
    }
  };

  return (
    <div className="payment-container">
      <h2>Payment</h2>
      <form onSubmit={handlePayment}>
        <div className="payment-methods">
          <div className="payment-method" onClick={() => setPaymentMethod('Credit Card')}>
            <input
              type="radio"
              id="credit-card"
              value="Credit Card"
              checked={paymentMethod === 'Credit Card'}
              onChange={() => setPaymentMethod('Credit Card')}
            />
            <label htmlFor="credit-card">Credit Card</label>
          </div>
          <div className="payment-method" onClick={() => setPaymentMethod('Debit Card')}>
            <input
              type="radio"
              id="debit-card"
              value="Debit Card"
              checked={paymentMethod === 'Debit Card'}
              onChange={() => setPaymentMethod('Debit Card')}
            />
            <label htmlFor="debit-card">Debit Card</label>
          </div>
          <div className="payment-method" onClick={() => setPaymentMethod('UPI')}>
            <input
              type="radio"
              id="upi"
              value="UPI"
              checked={paymentMethod === 'UPI'}
              onChange={() => setPaymentMethod('UPI')}
            />
            <label htmlFor="upi">UPI</label>
          </div>
          <div className="payment-method" onClick={() => setPaymentMethod('Net Banking')}>
            <input
              type="radio"
              id="net-banking"
              value="Net Banking"
              checked={paymentMethod === 'Net Banking'}
              onChange={() => setPaymentMethod('Net Banking')}
            />
            <label htmlFor="net-banking">Net Banking</label>
          </div>
        </div>
        <button type="submit" className="pay-button">
          Pay Now
        </button>
      </form>
    </div>
  );
};

export default Payment;
