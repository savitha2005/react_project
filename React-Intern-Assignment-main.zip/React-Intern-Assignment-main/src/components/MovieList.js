// src/components/MovieList.js
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import './MovieList.css'; 

const MovieList = () => {
  const [movies, setMovies] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchMovies = async () => {
      try {
        const response = await axios.get('https://api.example.com/user');
        const fetchedMovies = response.data.map(item => ({
          id: item.show.id,
          title: item.show.name,
          image: item.show.image ? item.show.image.medium : 'https://via.placeholder.com/210', // Fallback if no image
        }));
        setMovies(fetchedMovies);
        setLoading(false);
      } catch (err) {
        setError('Failed to fetch movies');
        setLoading(false);
      }
    };

    fetchMovies();
  }, []);

  const selectMovie = (id) => {
    // Simulate a seat selection page after clicking a movie
    navigate(`/seats/${id}`);
  };

  if (loading) return <p>Loading movies...</p>;
  if (error) return <p>{error}</p>;

  return (
    <div className="movie-list">
      {movies.map((movie) => (
        <div key={movie.id} className="movie-card" onClick={() => selectMovie(movie.id)}>
          <img src={movie.image} alt={movie.title} />
          <h3>{movie.title}</h3>
        </div>
      ))}
    </div>
  );
};

export default MovieList;
