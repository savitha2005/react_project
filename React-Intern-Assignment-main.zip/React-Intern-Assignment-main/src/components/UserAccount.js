// src/components/UserAccount.js
import React, { useEffect, useState } from 'react';
import jsPDF from 'jspdf';
import './UserAccount.css'; 

const UserAccount = () => {
  const [bookings, setBookings] = useState([]);

  useEffect(() => {
    const storedBookings = JSON.parse(localStorage.getItem('bookings')) || [];
    setBookings(storedBookings);
  }, []);

  const downloadTicket = (booking) => {
    const doc = new jsPDF();
    doc.setFontSize(20);
    doc.text('Movie Ticket', 20, 20);
    doc.setFontSize(14);
    doc.text(`Movie ID: ${booking.movieId}`, 20, 40);
    doc.text(`Date: ${booking.date}`, 20, 60);
    doc.text(`Seats: ${booking.seats.join(', ')}`, 20, 80);
    doc.save(`ticket_${booking.movieId}.pdf`);
  };

  return (
    <div className="user-account">
      <h2>Your Bookings</h2>
      {bookings.length === 0 ? (
        <p>No bookings available</p>
      ) : (
        <div className="bookings-list">
          {bookings.map((booking, index) => (
            <div key={index} className="booking-item">
              <h3>Movie ID: {booking.movieId}</h3>
              <p>Date: {booking.date}</p>
              <p>Seats: {booking.seats.join(', ')}</p>
              <button
                className="download-button"
                onClick={() => downloadTicket(booking)}
              >
                Download Ticket
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default UserAccount;

// src/components/UserAccount.js
// import React, { useEffect, useState } from 'react';
// import jsPDF from 'jspdf';
// import axios from 'axios';
// import './UserAccount.css'; 

// const UserAccount = () => {
//   const [bookings, setBookings] = useState([]);

//   useEffect(() => {
//     // Fetch bookings (assumed to be stored locally for now)
//     const storedBookings = JSON.parse(localStorage.getItem('bookings')) || [];
//     setBookings(storedBookings);
//   }, []);

//   const downloadTicket = async (booking) => {
//     // Generate PDF ticket
//     const doc = new jsPDF();
//     doc.setFontSize(20);
//     doc.text('Movie Ticket', 20, 20);
//     doc.setFontSize(14);
//     doc.text(`Movie ID: ${booking.movieId}`, 20, 40);
//     doc.text(`Date: ${booking.date}`, 20, 60);
//     doc.text(`Seats: ${booking.seats.join(', ')}`, 20, 80);
//     doc.save(`ticket_${booking.movieId}.pdf`);

//     // Update the booking status using Axios (you can add any additional fields)
//     try {
//       const response = await axios.put(`https://api.tvmaze.com/search/shows?q=all/${booking.movieId}`, {
//         downloaded: true, // Marking the ticket as downloaded
//         ...booking // Other fields if needed
//       });

//       if (response.status === 200) {
//         console.log('Booking updated successfully');
//         alert('Ticket downloaded and booking updated!');
//       } else {
//         console.error('Failed to update booking');
//       }
//     } catch (error) {
//       console.error('Error updating the booking:', error);
//     }
//   };

//   return (
//     <div className="user-account">
//       <h2>Your Bookings</h2>
//       {bookings.length === 0 ? (
//         <p>No bookings available</p>
//       ) : (
//         <div className="bookings-list">
//           {bookings.map((booking, index) => (
//             <div key={index} className="booking-item">
//               <h3>Movie ID: {booking.movieId}</h3>
//               <p>Date: {booking.date}</p>
//               <p>Seats: {booking.seats.join(', ')}</p>
//               <button
//                 className="download-button"
//                 onClick={() => downloadTicket(booking)}
//               >
//                 Download Ticket
//               </button>
//             </div>
//           ))}
//         </div>
//       )}
//     </div>
//   );
// };

// export default UserAccount;
