// src/App.js
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Navbar from './components/Navbar';
import Login from './components/Login';
import MovieList from './components/MovieList';
import SeatSelection from './components/SeatSelection';
import TicketConfirmation from './components/TicketConfirmation';
import UserAccount from './components/UserAccount';
import Payment from './components/Payment'; 

function App() {
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/movies" element={<MovieList />} />
        <Route path="/seats/:movieId" element={<SeatSelection />} />
        <Route path="/confirmation" element={<TicketConfirmation />} />
        <Route path="/account" element={<UserAccount />} />
        <Route path="/payment" element={<Payment />} /> 
      </Routes>
    </Router>
  );
}

export default App;
